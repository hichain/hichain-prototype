HIchain Prototype版 r1.0.1

操作方法などについてはこちらを参照してください
https://github.com/hichain/HIchain-Prototype

＜ライセンスについて＞

HIchain Prototype版
Copyright (C) 2016 Tokiwa
Copyright (C) 2016 Unno
Copyright (C) 2016 Ruk

本ソフトウェアは個人利用のみ使用できる
再配布､複製､改変を禁ずる